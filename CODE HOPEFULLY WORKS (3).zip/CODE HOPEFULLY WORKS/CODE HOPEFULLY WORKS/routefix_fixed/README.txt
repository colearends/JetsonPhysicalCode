# SDSU Shuttle Navigator (Option 2) — Calibrated + Edit

Calibrated bounds:
- south: 44.314073599
- west:  -96.793709521
- north: 44.326144505
- east:  -96.773921607

Run:
1) npx http-server -p 8080
2) Open http://localhost:8080

Editing:
- Click "Edit Sidewalks" to enable Leaflet.Draw toolbar.
- Draw / edit / delete sidewalk polylines.
- Click "Export Edits" to download updated ways + nodes + edges.
- To persist edits, replace files in /data with the exported versions.
