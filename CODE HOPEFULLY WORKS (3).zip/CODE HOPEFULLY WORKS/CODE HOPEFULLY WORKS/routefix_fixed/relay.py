import asyncio
import serial
import websockets

# CHANGE THIS to your HC-05 COM port (likely COM10)
BT_PORT = "COM10"
BT_BAUD = 9600

ser = serial.Serial(BT_PORT, BT_BAUD, timeout=0.1)

async def handler(websocket):
    async for message in websocket:
        print("From browser:", message)
        ser.write((message + "\n").encode())

async def main():
    async with websockets.serve(handler, "localhost", 8215):
        print("Relay running on ws://localhost:8215")
        await asyncio.Future()

asyncio.run(main())
