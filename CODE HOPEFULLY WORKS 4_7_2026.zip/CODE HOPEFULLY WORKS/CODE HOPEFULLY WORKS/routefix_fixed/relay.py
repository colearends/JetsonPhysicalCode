import asyncio
import serial
import websockets
import json

BT_PORT = "COM9"
BT_BAUD = 9600

ser = serial.Serial(BT_PORT, BT_BAUD, timeout=0.1)

async def handler(websocket):
    async def read_serial():
        while True:
            line = ser.readline().decode(errors="ignore").strip()
            if line:
                print("From Arduino:", line)

                # ⭐ NEW: Forward ARM status (kill switch state)
                if "ARM=" in line:
                    await websocket.send(line)

                # Parse steerCounts and brakeCounts if present
                if "steerCounts" in line:
                    parts = line.split()
                    steer = None
                    brake = None

                    for p in parts:
                        if p.startswith("steerCounts="):
                            steer = int(p.split("=")[1])
                        if p.startswith("brakeCounts="):
                            brake = int(p.split("=")[1])

                    await websocket.send(json.dumps({
                        "steerCounts": steer,
                        "brakeCounts": brake
                    }))

            await asyncio.sleep(0.01)

    # Start serial reader in background
    asyncio.create_task(read_serial())

    # Handle browser → Arduino
    async for message in websocket:
        print("From browser:", message)
        ser.write((message + "\n").encode())

async def main():
    async with websockets.serve(handler, "localhost", 8217):
        print("Relay running on ws://localhost:8217")
        await asyncio.Future()

asyncio.run(main())
